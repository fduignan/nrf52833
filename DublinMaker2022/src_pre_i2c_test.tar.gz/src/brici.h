void ClassicBrici(void);
void Brici(brick *Bricks, uint16_t Brick_Count, uint16_t BatWidth,uint16_t demo_mode);
