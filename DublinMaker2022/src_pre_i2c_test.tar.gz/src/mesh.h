#ifndef __mesh_h
#define __mesh_h
extern "C" void mesh_begin(void);
extern "C" void sendDMBMessage(uint32_t data);
#endif
